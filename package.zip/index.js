// Re-export the handler from the modular structure
export { handler } from './src/handler.js';